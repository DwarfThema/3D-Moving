﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraRotate : MonoBehaviour
{
    float rotateX;
    float rotateY;

    public float rotateSpeed = 500;

    Vector3 cameraNear;
    Vector3 cameraFar;

    float wheelValue = 0;

    // Start is called before the first frame update
    void Start()
    {
        cameraNear = transform.localPosition;
        //localPosition 으로 내 부모를 기준으로한 위치로 간다.

    }

    // Update is called once per frame
    void Update()
    {
        float axisX = Input.GetAxis("Mouse X");
        float axisY = Input.GetAxis("Mouse Y");

        rotateX += axisY * rotateSpeed * Time.deltaTime;
        rotateY += axisX * rotateSpeed * Time.deltaTime;

        rotateX = Mathf.Clamp(rotateX, -80, 80);

        transform.eulerAngles = new Vector3(-rotateX, rotateY, 0);




        cameraFar = cameraNear + transform.forward * -5;
        //가장 가까운 카메라 지점에서 앞쪽으로 -5을 곱해줌으로 5미터 뒤로 간다는 뜻
        //음수로 곱해주면 방향의 뒷방향이며 5미터 뒤라는 의미


        wheelValue -= Input.GetAxis("Mouse ScrollWheel");

        wheelValue = Mathf.Clamp(wheelValue, 0, 1.0f);

        Vector3 cameraPosition = Vector3.Lerp(cameraNear, cameraFar, wheelValue);
        
        
        transform.localPosition = cameraPosition;
    }
}
